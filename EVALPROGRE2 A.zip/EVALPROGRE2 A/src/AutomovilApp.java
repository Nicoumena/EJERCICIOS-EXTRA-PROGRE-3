import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

class Automovil {
    int codigo;
    String marca;
    int cilindraje;
    float precio;

    public Automovil(int codigo, String marca, int cilindraje, float precio) {
        this.codigo = codigo;
        this.marca = marca;
        this.cilindraje = cilindraje;
        this.precio = precio;
    }

    public String toString() {
        return "Código: " + codigo + ", Marca: " + marca + ", Cilindraje: " + cilindraje + ", Precio: $" + precio;
    }
}

public class AutomovilApp extends JFrame {
    private JComboBox<String> marcaCombo, cilindrajeCombo, marcaFiltroCombo;
    private JTextField codigoField, precioField;
    private JTextArea textArea, textAreaFiltro, textAreaSuma;
    private ArrayList<Automovil> automoviles;

    private final String[] MARCAS = {"KIA", "BMW", "TOYOTA", "JAC", "HYUNDAI"};
    private final Integer[] CILINDRAJES = {1300, 1600, 2000, 2400, 2700};

    public AutomovilApp() {
        automoviles = new ArrayList<>();

        // Lista predefinida de 4 automóviles
        automoviles.add(new Automovil(101, "KIA", 1300, 8000));
        automoviles.add(new Automovil(102, "BMW", 2400, 45000));
        automoviles.add(new Automovil(103, "TOYOTA", 1600, 12000));
        automoviles.add(new Automovil(104, "JAC", 2000, 10000));

        setTitle("Gestión de Automóviles");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        add(tabbedPane, BorderLayout.CENTER);

        JPanel panel1 = new JPanel(new GridLayout(6, 2));

        codigoField = new JTextField();
        precioField = new JTextField();
        marcaCombo = new JComboBox<>(MARCAS);
        cilindrajeCombo = new JComboBox<>(Arrays.stream(CILINDRAJES).map(String::valueOf).toArray(String[]::new));

        JButton agregarBtn = new JButton("Agregar Automóvil");
        textArea = new JTextArea();
        JScrollPane scroll1 = new JScrollPane(textArea);

        panel1.add(new JLabel("Código (3 dígitos):"));
        panel1.add(codigoField);
        panel1.add(new JLabel("Marca:"));
        panel1.add(marcaCombo);
        panel1.add(new JLabel("Cilindraje:"));
        panel1.add(cilindrajeCombo);
        panel1.add(new JLabel("Precio ($):"));
        panel1.add(precioField);
        panel1.add(agregarBtn);
        panel1.add(new JLabel());
        panel1.add(scroll1);

        agregarBtn.addActionListener(e -> agregarAutomovil());
        tabbedPane.addTab("Ingreso", panel1);

        JPanel panel2 = new JPanel(new BorderLayout());
        marcaFiltroCombo = new JComboBox<>(MARCAS);
        JButton filtrarBtn = new JButton("Filtrar por marca");
        textAreaFiltro = new JTextArea();
        JScrollPane scroll2 = new JScrollPane(textAreaFiltro);
        JPanel topPanel2 = new JPanel();
        topPanel2.add(new JLabel("Marca:"));
        topPanel2.add(marcaFiltroCombo);
        topPanel2.add(filtrarBtn);

        panel2.add(topPanel2, BorderLayout.NORTH);
        panel2.add(scroll2, BorderLayout.CENTER);

        filtrarBtn.addActionListener(e -> filtrarPorMarca());
        tabbedPane.addTab("Filtrado", panel2);

        JPanel panel3 = new JPanel(new BorderLayout());
        JComboBox<String> marcaSumaCombo = new JComboBox<>(MARCAS);
        JButton sumarBtn = new JButton("Sumar precios");
        textAreaSuma = new JTextArea();
        JScrollPane scroll3 = new JScrollPane(textAreaSuma);
        JPanel topPanel3 = new JPanel();
        topPanel3.add(new JLabel("Marca:"));
        topPanel3.add(marcaSumaCombo);
        topPanel3.add(sumarBtn);

        panel3.add(topPanel3, BorderLayout.NORTH);
        panel3.add(scroll3, BorderLayout.CENTER);

        sumarBtn.addActionListener(e -> {
            String marcaSeleccionada = (String) marcaSumaCombo.getSelectedItem();
            float suma = sumarPreciosRecursivo(automoviles.iterator(), marcaSeleccionada);
            textAreaSuma.setText("Suma total de precios para " + marcaSeleccionada + ": $" + suma);
        });

        tabbedPane.addTab("Sumatoria", panel3);
        actualizarTextArea();
        setVisible(true);
    }

    private void agregarAutomovil() {
        try {
            int codigo = Integer.parseInt(codigoField.getText());
            if (String.valueOf(codigo).length() != 3) {
                JOptionPane.showMessageDialog(this, "El código debe tener 3 dígitos.");
                return;
            }
            for (Automovil a : automoviles) {
                if (a.codigo == codigo) {
                    JOptionPane.showMessageDialog(this, "Código ya ingresado.");
                    return;
                }
            }
            String marca = (String) marcaCombo.getSelectedItem();
            int cilindraje = Integer.parseInt((String) cilindrajeCombo.getSelectedItem());
            float precio = Float.parseFloat(precioField.getText());

            if (precio < 5000 || precio > 100000) {
                JOptionPane.showMessageDialog(this, "Precio fuera del rango permitido.");
                return;
            }
            automoviles.add(new Automovil(codigo, marca, cilindraje, precio));
            actualizarTextArea();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error en formato numérico.");
        }
    }

    private void actualizarTextArea() {
        textArea.setText("");
        for (Automovil a : automoviles) {
            textArea.append(a.toString() + "\n");
        }
    }

    private void filtrarPorMarca() {
        String marca = (String) marcaFiltroCombo.getSelectedItem();
        ArrayList<Automovil> otros = new ArrayList<>();
        for (Automovil a : automoviles) {
            if (!a.marca.equals(marca)) {
                otros.add(a);
            }
        }
        otros.sort(Comparator.comparingInt(a -> a.cilindraje));
        textAreaFiltro.setText("");
        for (Automovil a : otros) {
            textAreaFiltro.append(a.toString() + "\n");
        }
    }

    private float sumarPreciosRecursivo(Iterator<Automovil> it, String marca) {
        if (!it.hasNext()) return 0;
        Automovil actual = it.next();
        if (actual.marca.equals(marca)) {
            return actual.precio + sumarPreciosRecursivo(it, marca);
        } else {
            return sumarPreciosRecursivo(it, marca);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AutomovilApp::new);
    }
}