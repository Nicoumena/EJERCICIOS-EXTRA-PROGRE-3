import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

class Motocicleta {
    int codigo;
    String marca;
    int cilindraje;
    String color;
    float precio;

    public Motocicleta(int codigo, String marca, int cilindraje, String color, float precio) {
        this.codigo = codigo;
        this.marca = marca;
        this.cilindraje = cilindraje;
        this.color = color;
        this.precio = precio;
    }

    public String toString() {
        return "Código: " + codigo + ", Marca: " + marca + ", Cilindraje: " + cilindraje + ", Color: " + color + ", Precio: $" + precio;
    }
}

public class MotocicletaApp extends JFrame {
    private JTextField codigoField, precioField;
    private JComboBox<String> marcaCombo, cilindrajeCombo, colorCombo, colorFiltroCombo;
    private JTextArea textArea;
    private DefaultListModel<String> listModel;
    private JList<String> colorList;
    private ArrayList<Motocicleta> motocicletas;

    private final String[] MARCAS = {"HONDA", "BMW", "Vespa", "Royal Enfield"};
    private final Integer[] CILINDRAJES = {300, 500, 800, 1000};
    private final String[] COLORES = {"Rojo", "Negro", "Blanco", "Azul", "Verde"};

    public MotocicletaApp() {
        motocicletas = new ArrayList<>();

        motocicletas.add(new Motocicleta(1001, "HONDA", 300, "Rojo", 2000));
        motocicletas.add(new Motocicleta(1002, "BMW", 800, "Negro", 8000));
        motocicletas.add(new Motocicleta(1003, "Vespa", 500, "Blanco", 2500));
        motocicletas.add(new Motocicleta(1004, "Royal Enfield", 1000, "Verde", 7000));
        motocicletas.add(new Motocicleta(1005, "HONDA", 500, "Azul", 4000));

        setTitle("Gestión de Motocicletas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        add(tabbedPane, BorderLayout.CENTER);

        // TAB 1: Ingreso
        JPanel panel1 = new JPanel(new GridLayout(7, 2));
        codigoField = new JTextField();
        precioField = new JTextField();
        marcaCombo = new JComboBox<>(MARCAS);
        cilindrajeCombo = new JComboBox<>(Arrays.stream(CILINDRAJES).map(String::valueOf).toArray(String[]::new));
        colorCombo = new JComboBox<>(COLORES);
        JButton agregarBtn = new JButton("Agregar/Actualizar Motocicleta");
        textArea = new JTextArea();
        JScrollPane scroll1 = new JScrollPane(textArea);

        panel1.add(new JLabel("Código (4 dígitos):"));
        panel1.add(codigoField);
        panel1.add(new JLabel("Marca:"));
        panel1.add(marcaCombo);
        panel1.add(new JLabel("Cilindraje:"));
        panel1.add(cilindrajeCombo);
        panel1.add(new JLabel("Color:"));
        panel1.add(colorCombo);
        panel1.add(new JLabel("Precio ($):"));
        panel1.add(precioField);
        panel1.add(agregarBtn);
        panel1.add(new JLabel());
        panel1.add(scroll1);

        agregarBtn.addActionListener(e -> agregarMotocicleta());
        tabbedPane.addTab("Ingreso", panel1);

        // TAB 2: Filtro por color
        JPanel panel2 = new JPanel(new BorderLayout());
        colorFiltroCombo = new JComboBox<>(COLORES);
        JButton filtrarBtn = new JButton("Filtrar por color");
        listModel = new DefaultListModel<>();
        colorList = new JList<>(listModel);
        JScrollPane scroll2 = new JScrollPane(colorList);
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Color:"));
        topPanel.add(colorFiltroCombo);
        topPanel.add(filtrarBtn);

        panel2.add(topPanel, BorderLayout.NORTH);
        panel2.add(scroll2, BorderLayout.CENTER);

        filtrarBtn.addActionListener(e -> filtrarPorColor());
        tabbedPane.addTab("Filtrar por Color", panel2);

        actualizarTextArea();
        setVisible(true);
    }

    private void agregarMotocicleta() {
        try {
            int codigo = Integer.parseInt(codigoField.getText());
            if (String.valueOf(codigo).length() != 4) {
                JOptionPane.showMessageDialog(this, "El código debe tener 4 dígitos.");
                return;
            }
            float precio = Float.parseFloat(precioField.getText());
            if (precio < 1500 || precio >= 30000) {
                JOptionPane.showMessageDialog(this, "Precio fuera del rango permitido.");
                return;
            }
            String marca = (String) marcaCombo.getSelectedItem();
            int cilindraje = Integer.parseInt((String) cilindrajeCombo.getSelectedItem());
            String color = (String) colorCombo.getSelectedItem();

            boolean actualizado = false;
            for (int i = 0; i < motocicletas.size(); i++) {
                if (motocicletas.get(i).codigo == codigo) {
                    motocicletas.set(i, new Motocicleta(codigo, marca, cilindraje, color, precio));
                    actualizado = true;
                    break;
                }
            }
            if (!actualizado) motocicletas.add(new Motocicleta(codigo, marca, cilindraje, color, precio));
            actualizarTextArea();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error en formato numérico.");
        }
    }

    private void actualizarTextArea() {
        textArea.setText("");
        for (Motocicleta m : motocicletas) {
            textArea.append(m.toString() + "\n");
        }
    }

    private void filtrarPorColor() {
        String colorSeleccionado = (String) colorFiltroCombo.getSelectedItem();
        ArrayList<Motocicleta> filtradas = new ArrayList<>();
        for (Motocicleta m : motocicletas) {
            if (m.color.equals(colorSeleccionado)) filtradas.add(m);
        }
        filtradas.sort(Comparator.comparingDouble(m -> m.precio)); // Ordenar de menor a mayor
        listModel.clear();
        for (Motocicleta m : filtradas) {
            listModel.addElement(m.toString());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MotocicletaApp::new);
    }
}
