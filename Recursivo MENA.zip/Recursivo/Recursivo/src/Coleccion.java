import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class Coleccion {
    private List<Transformer> lista;

    public Coleccion() {
        lista = new ArrayList<>();
    }

    public void agregar(Transformer dato) {
        if (existeId(dato.getId())) {
            JOptionPane.showMessageDialog(null, "El ID " + dato.getId() + " ya está registrado. No se puede agregar.");
            return;
        }
        lista.add(dato);
    }

    private boolean existeId(int id) {
        for (Transformer t : lista) {
            if (t.getId() == id) return true;
        }
        return false;
    }

    public String listar() {
        StringBuilder sb = new StringBuilder();
        for (Transformer t : lista) {
            sb.append(t.toString()).append("\n");
        }
        return sb.toString();
    }

    public float sumar(int indice) {
        if (indice == lista.size())
            return 0;
        else
            return sumar(indice + 1) + lista.get(indice).getPoder();
    }

    // Sumatoria por facción
    public float sumarPorFaccion(String faccion) {
        float suma = 0;
        String faccionNormalizada = faccion.trim().toLowerCase();
        for (Transformer t : lista) {
            if (t.getFaccion().trim().toLowerCase().equals(faccionNormalizada)) {
                suma += t.getPoder();
            }
        }
        return suma;
    }
}
