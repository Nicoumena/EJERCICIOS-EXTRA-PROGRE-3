import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

class Automovil {
    int codigo;
    String marca;
    int cilindraje;
    float precio;

    public Automovil(int codigo, String marca, int cilindraje, float precio) {
        this.codigo = codigo;
        this.marca = marca;
        this.cilindraje = cilindraje;
        this.precio = precio;
    }

    public String toString() {
        return "Código: " + codigo + ", Marca: " + marca + ", Cilindraje: " + cilindraje + ", Precio: $" + precio;
    }
}

public class AutomovilApp extends JFrame {
    private JTextField codigoField, precioField;
    private JComboBox<String> marcaCombo, cilindrajeCombo, marcaFiltroCombo, marcaContarCombo;
    private JTextArea textAreaLista, textAreaFiltro, textAreaContador;
    private ArrayList<Automovil> automoviles;

    private final String[] MARCAS = {"KIA", "BMW", "TOYOTA", "HONDA", "JAC"};
    private final Integer[] CILINDRAJES = {1300, 1600, 2000, 2400, 2700};

    public AutomovilApp() {
        automoviles = new ArrayList<>();

        // Lista predefinida
        automoviles.add(new Automovil(101, "KIA", 1300, 6000));
        automoviles.add(new Automovil(102, "BMW", 2400, 32000));
        automoviles.add(new Automovil(103, "TOYOTA", 2000, 15000));
        automoviles.add(new Automovil(104, "JAC", 1600, 9800));

        setTitle("Gestión de Automóviles");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(850, 600);
        setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        add(tabbedPane, BorderLayout.CENTER);

        // TAB 1: Ingreso y listado
        JPanel panel1 = new JPanel(new GridLayout(6, 2));
        codigoField = new JTextField();
        precioField = new JTextField();
        marcaCombo = new JComboBox<>(MARCAS);
        cilindrajeCombo = new JComboBox<>(Arrays.stream(CILINDRAJES).map(String::valueOf).toArray(String[]::new));
        textAreaLista = new JTextArea();
        JScrollPane scroll1 = new JScrollPane(textAreaLista);
        JButton agregarBtn = new JButton("Agregar/Actualizar Automóvil");

        panel1.add(new JLabel("Código (3 dígitos):"));
        panel1.add(codigoField);
        panel1.add(new JLabel("Marca:"));
        panel1.add(marcaCombo);
        panel1.add(new JLabel("Cilindraje:"));
        panel1.add(cilindrajeCombo);
        panel1.add(new JLabel("Precio ($):"));
        panel1.add(precioField);
        panel1.add(agregarBtn);
        panel1.add(new JLabel());
        panel1.add(scroll1);

        agregarBtn.addActionListener(e -> agregarAutomovil());
        tabbedPane.addTab("Ingreso", panel1);

        // TAB 2: Filtro por marca y precio
        JPanel panel2 = new JPanel(new BorderLayout());
        JPanel topPanel2 = new JPanel();
        marcaFiltroCombo = new JComboBox<>(MARCAS);
        JTextField precioFiltroField = new JTextField(8);
        JButton filtroBtn = new JButton("Filtrar");
        textAreaFiltro = new JTextArea();
        JScrollPane scroll2 = new JScrollPane(textAreaFiltro);

        topPanel2.add(new JLabel("Marca:"));
        topPanel2.add(marcaFiltroCombo);
        topPanel2.add(new JLabel("Precio mínimo:"));
        topPanel2.add(precioFiltroField);
        topPanel2.add(filtroBtn);

        filtroBtn.addActionListener(e -> {
            String marca = (String) marcaFiltroCombo.getSelectedItem();
            try {
                float precio = Float.parseFloat(precioFiltroField.getText());
                ArrayList<Automovil> filtrados = new ArrayList<>();
                for (Automovil a : automoviles) {
                    if (a.marca.equals(marca) && a.precio > precio) {
                        filtrados.add(a);
                    }
                }
                filtrados.sort(Comparator.comparingDouble(a -> -a.precio));
                textAreaFiltro.setText("");
                for (Automovil a : filtrados) {
                    textAreaFiltro.append(a.toString() + "\n");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese un precio válido.");
            }
        });

        panel2.add(topPanel2, BorderLayout.NORTH);
        panel2.add(scroll2, BorderLayout.CENTER);
        tabbedPane.addTab("Filtrado", panel2);

        // TAB 3: Contador recursivo por marca
        JPanel panel3 = new JPanel(new BorderLayout());
        JPanel topPanel3 = new JPanel();
        marcaContarCombo = new JComboBox<>(MARCAS);
        JButton contarBtn = new JButton("Contar por marca");
        textAreaContador = new JTextArea();
        JScrollPane scroll3 = new JScrollPane(textAreaContador);

        topPanel3.add(new JLabel("Marca:"));
        topPanel3.add(marcaContarCombo);
        topPanel3.add(contarBtn);

        contarBtn.addActionListener(e -> {
            String marca = (String) marcaContarCombo.getSelectedItem();
            int cantidad = contarRecursivo(automoviles.iterator(), marca);
            textAreaContador.setText("Cantidad de automóviles de la marca " + marca + ": " + cantidad);
        });

        panel3.add(topPanel3, BorderLayout.NORTH);
        panel3.add(scroll3, BorderLayout.CENTER);
        tabbedPane.addTab("Contador", panel3);

        actualizarLista();
        setVisible(true);
    }

    private void agregarAutomovil() {
        try {
            int codigo = Integer.parseInt(codigoField.getText());
            if (String.valueOf(codigo).length() != 3) {
                JOptionPane.showMessageDialog(this, "Código debe tener 3 dígitos.");
                return;
            }
            float precio = Float.parseFloat(precioField.getText());
            if (precio < 5000 || precio > 100000) {
                JOptionPane.showMessageDialog(this, "Precio fuera de rango.");
                return;
            }
            String marca = (String) marcaCombo.getSelectedItem();
            int cilindraje = Integer.parseInt((String) cilindrajeCombo.getSelectedItem());

            boolean actualizado = false;
            for (int i = 0; i < automoviles.size(); i++) {
                if (automoviles.get(i).codigo == codigo) {
                    automoviles.set(i, new Automovil(codigo, marca, cilindraje, precio));
                    actualizado = true;
                    break;
                }
            }
            if (!actualizado) automoviles.add(new Automovil(codigo, marca, cilindraje, precio));
            actualizarLista();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error en formato numérico.");
        }
    }

    private void actualizarLista() {
        textAreaLista.setText("");
        for (Automovil a : automoviles) {
            textAreaLista.append(a.toString() + "\n");
        }
    }

    private int contarRecursivo(Iterator<Automovil> it, String marca) {
        if (!it.hasNext()) return 0;
        Automovil actual = it.next();
        return (actual.marca.equals(marca) ? 1 : 0) + contarRecursivo(it, marca);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AutomovilApp::new);
    }
}